
#############################                 Thompson                 ##############################          



#library(dplyr)
##All possible combinations - Image(i) -inrows
comb = c(0.102,0.0923,0.063,0.056,
         0.103,0.116,0.098,0.077,
         0.078,0.0903,0.087,0.075,
         0.088,0.0877,0.0826,0.055,
         0.076,0.0864,0.100,0.051,
         0.074,0.085,0.091,0.094)

Donation = 21
Target_pop = 100000000
len = length(comb)
play = 0
Total_Donation=0

####Thompson
a = c(1,1,1,1,
      1,1,1,1,
      1,1,1,1,
      1,1,1,1,
      1,1,1,1,
      1,1,1,1)
b = c(1,1,1,1,
      1,1,1,1,
      1,1,1,1,
      1,1,1,1,
      1,1,1,1,
      1,1,1,1)
beta = c(0,0,0,0,
          0,0,0,0,
          0,0,0,0,
          0,0,0,0,
          0,0,0,0,
          0,0,0,0)
###initial run 

for(i in 1:(Target_pop))
{
  if(i%%100000==0)
  {print(i)}
  for(j in 1:len)
  {
    beta[j]=rbeta(1,a[j],b[j])
  }
  index=which.max(beta)
  play=rbinom(1,1,comb[index])
  Total_Donation=Total_Donation + play*21
  if (play>0) {
    a[index]=a[index]+1
  }
  if (play<1) {
    b[index]=b[index]+1
  }
}


##TotalDonation
Total_Donation

a
b
a+b
which.max(a+b)
a/(a+b)
