#library(dplyr)
#############################                 UCB1                 ##############################          

##All possible combinations - Image(i) -inrows
comb = c(0.102,0.0923,0.063,0.056,
         0.103,0.116,0.098,0.077,
         0.078,0.0903,0.087,0.075,
         0.088,0.0877,0.0826,0.055,
         0.076,0.0864,0.100,0.051,
         0.074,0.085,0.091,0.094)

Donation = 21
Target_pop = 100000000
len = length(comb)
play = 0
Total_Donation=0

####UCB1
u = c(0,0,0,0,
      0,0,0,0,
      0,0,0,0,
      0,0,0,0,
      0,0,0,0,
      0,0,0,0)
uPlus = c(0,0,0,0,
      0,0,0,0,
      0,0,0,0,
      0,0,0,0,
      0,0,0,0,
      0,0,0,0)

n = c(0,0,0,0,
      0,0,0,0,
      0,0,0,0,
      0,0,0,0,
      0,0,0,0,
      0,0,0,0)

###initial run 

for(i in 1:len)
{
  u[i]=rbinom(1,1,comb[i])
  n[i]=n[i]+1
}
Total_Donation=sum(u)*21


for(i in 1:(Target_pop-len))
{
  if(i%%100000==0)
  {print(i)}
  for(j in 1:len)
  {
  uPlus[j]=u[j]+sqrt(2 * log10(i)/n[j])
  }
  index=which.max(uPlus)
  play=rbinom(1,1,comb[index])
  Total_Donation=Total_Donation + play*21
  u[index]=(u[index]*n[index]+play)/(n[index] + 1)
  n[index] = n[index] + 1
}

sum(n)
##TotalDonation
Total_Donation

##position of best version
which.max(u)
##prob of best version
max(u)

u
n

