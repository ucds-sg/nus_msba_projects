#library(dplyr)
#############################                 Thompson                 ##############################          

##All possible combinations - Image(i) -inrows
comb = c(0.102,0.0923,0.063,0.056,
         0.103,0.116,0.098,0.077,
         0.078,0.0903,0.087,0.075,
         0.088,0.0877,0.0826,0.055,
         0.076,0.0864,0.100,0.051,
         0.074,0.085,0.091,0.094)
cust = matrix(comb,4,6)
rnam<-c('c1','c2','c3','c4')
row.names(cust)<-rnam
cnam<-c('P1','P2','P3','P4','P5','P6')
colnames(cust)<-cnam
cust

Target_pop = 400000
len = ncol(cust)
iter =nrow(cust)
play = 0
####Thompson
one =c(1,1,1,1,
      1,1,1,1,
      1,1,1,1,
      1,1,1,1,
      1,1,1,1,
      1,1,1,1)
ze = c(0,0,0,0,
       0,0,0,0,
       0,0,0,0,
       0,0,0,0,
       0,0,0,0,
       0,0,0,0)
a = matrix(one,4,6)
b = matrix(one,4,6)
beta = matrix(ze,4,6)

###run 

for(t in 1:(Target_pop/iter))
{
for(i in 1:iter)
{
  for(j in 1:len)
  {
    beta[i,j]=rbeta(1,a[i,j],b[i,j])
  }
  index=which.max(beta[i,])
  play=rbinom(1,1,cust[i,index])
  if (play==0) {
    a[i,index]=a[i,index]+1
  }
  if (play==1) {
    b[i,index]=b[i,index]+1
  }
}
}
a
b
a+b
