#library(dplyr)
#############################                 UCB1                 ##############################          

##All possible combinations - Image(i) -inrows
comb = c(0.102,0.0923,0.063,0.056,
         0.103,0.116,0.098,0.077,
         0.078,0.0903,0.087,0.075,
         0.088,0.0877,0.0826,0.055,
         0.076,0.0864,0.100,0.051,
         0.074,0.085,0.091,0.094)
cust = matrix(comb,4,6)
rnam<-c('c1','c2','c3','c4')
row.names(cust)<-rnam
cnam<-c('P1','P2','P3','P4','P5','P6')
colnames(cust)<-cnam
cust

Target_pop = 400000
len = ncol(cust)
iter =nrow(cust)
play = 0
####UCB1
ze = c(0,0,0,0,
      0,0,0,0,
      0,0,0,0,
      0,0,0,0,
      0,0,0,0,
      0,0,0,0)
u = matrix(ze,4,6)
uPlus = matrix(ze,4,6)
n = matrix(ze,4,6)

###initial run 
for (i in 1:iter) 
  {
  for(j in 1:len)
  {
    u[i,j]=rbinom(1,1,cust[i,j])
    n[i,j]=n[i,j]+1
  }
}



for(t in 1:(Target_pop/iter - len))
{
  
for(i in 1:iter)
{
  for(j in 1:len)
  {
    uPlus[i,j]=u[i,j]+sqrt(2 * log10(t)/n[i,j])
  }
  index=which.max(uPlus[i,])
  play=rbinom(1,1,cust[i,index])
  u[i,index]=(u[i,index]*n[i,index]+play)/(n[i,index] + 1)
  n[i,index] = n[i,index] + 1
}
}  

n
u
